package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;


@Service
public class UserServiceImpl implements UserService {
	
    @Autowired
	UserRepository repository;

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return repository.save(user);
	}

	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public User fetchUserById(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public void deleteUserById(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	@Override
	public User updateUser(Long id, User name) {
		User user=repository.findById(id).get();
		if(Objects.nonNull(name.getName()) &&
			       !"".equalsIgnoreCase(name.getName())) {
			           user.setName(name.getName());
		}
		if(Objects.nonNull(name.getType()) &&
	               !"".equalsIgnoreCase(name.getType())) {
	           user.setType(name.getType());
	       }
		if(Objects.nonNull(name.getPassword())) 
	              {
	           user.setPassword(name.getPassword());
	       }
		return repository.save(user);
	}

	
    
}
