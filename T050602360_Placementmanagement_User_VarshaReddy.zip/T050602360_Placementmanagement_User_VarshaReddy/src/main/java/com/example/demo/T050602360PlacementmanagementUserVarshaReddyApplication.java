package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T050602360PlacementmanagementUserVarshaReddyApplication {

	public static void main(String[] args) {
		SpringApplication.run(T050602360PlacementmanagementUserVarshaReddyApplication.class, args);
	}

}
