package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.User;

public interface UserService {

	User saveUser(User user);

	List<User> fetchUserList();

	User fetchUserById(Long id);

	void deleteUserById(Long id);

	User updateUser(Long id, User name);

	

	

}
